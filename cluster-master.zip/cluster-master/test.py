# coding: utf-8
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

cust_df = pd.read_csv(
    "http://pythondatascience.plavox.info/wp-content/uploads/2016/05/Wholesale_customers_data.csv")
del(cust_df['Channel'])
del(cust_df['Region'])
cust_df
cust_array = np.array([cust_df['Fresh'].tolist(),
                       cust_df['Milk'].tolist(),
                       cust_df['Grocery'].tolist(),
                       cust_df['Frozen'].tolist(),
                       cust_df['Milk'].tolist(),
                       cust_df['Detergents_Paper'].tolist(),
                       cust_df['Delicassen'].tolist()
                       ], np.int32)

cust_array = cust_array.T
pred = KMeans(n_clusters=4).fit_predict(cust_array)


cust_df['cluster_id'] = pred
cust_df
cust_df['cluster_id'].value_counts()
cust_df[cust_df['cluster_id'] == 0].mean()
cust_df[cust_df['cluster_id'] == 1].mean()
cust_df[cust_df['cluster_id'] == 2].mean()
cust_df[cust_df['cluster_id'] == 3].mean()

clusterinfo = pd.DataFrame()
for i in range(4):
    clusterinfo['cluster' +
                str(i)] = cust_df[cust_df['cluster_id'] == i].mean()
clusterinfo = clusterinfo.drop('cluster_id')

my_plot = clusterinfo.T.plot(
    kind='bar', stacked=True, title="Mean Value of 4 Clusters")
my_plot.set_xticklabels(my_plot.xaxis.get_majorticklabels(), rotation=0)

plt.show()
