# -*- coding: utf-8 -*-
import pandas as pd
from scipy.cluster.hierarchy import dendrogram, linkage
import matplotlib.pyplot as plt
import random

# methodのリスト
method_list = ("average", "centroid", "complete",
               "median", "single", "ward", "weighted")
data = []   # dataを格納するリスト
label = []  # labelを格納するリスト

# dataを20個生成
for i in range(20):
    num = random.randint(0, 99)
    data.append(num)
    label.append(str(num))

# DataFrameオブジェクト生成
df = pd.DataFrame(data)

# クラスタリング
for method in method_list:
    Z = linkage(df, method=method, metric="euclidean")
    dendrogram(Z, labels=label)
    plt.title(method)
    plt.show()
